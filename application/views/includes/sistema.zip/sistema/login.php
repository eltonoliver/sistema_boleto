<?php include "include-header.php" ?>

		<div class="container">
			<div class="col-md-4"></div>
			
			<div class="col-md-4 lo-gin">
				<img src="imagens/logo-civilcorp.png" alt="Civil Corp" width="" height="">
				
				<form action="" class="boxfor">
					<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nome do usuário ou e-mail" required="required">
					<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Senha" required="required">
					<button type="submit" class="btn btn-default btnlog">Entrar</button>
				</form>
				
				<p><a href="recuperarsenha.php">Esqueci minha senha</a></p>
				<p><a href="cadastro.php">Criar uma conta</a></p>
				
			</div>
			
			<div class="col-md-4"></div>
		</div>

<?php include "include-footer.php" ?>