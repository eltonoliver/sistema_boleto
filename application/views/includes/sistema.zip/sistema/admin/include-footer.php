		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap-filestyle.min.js"> </script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/jquery.slicknav.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('#menu').slicknav();
			});
			$(":file").filestyle({buttonBefore: true});
		</script>
	</body>
</html>