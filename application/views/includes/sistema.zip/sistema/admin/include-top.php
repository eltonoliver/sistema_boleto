				<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 top">
					<div class="row">
						<div class="col-md-4 txtalg text-uppercase visivel">
							<h4>Nome do administrador</h4>
						</div>
						<div class="col-md-4 call">
							<select  class="form-control">
								<option value="Nome">Nome</option>
								<option value="CPF">CPF</option>
								<option value="Nosso número">Nosso número</option>
							</select>
						</div>
						<div class="col-md-4 call">
							<div class="input-group">
								<input type="text" class="form-control">
								<span class="input-group-btn">
									<button class="btn btn-default" type="button">Pesquisar</button>
								</span>
							</div>
						</div>
					</div>
				</div>