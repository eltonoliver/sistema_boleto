			<div class="boxlogo"><img src="../imagens/logo-civilcorp.png" alt="Civil Corp" width="" height=""></div>


			<div class="row">
				<nav>
					<ul id="menu">
						<li><a class="menu-bt" href="index.php" id="home">Home</a></li>
						<li><a class="menu-bt" href="clientes.php" id="clientes">Clientes</a></li>
						<li><a class="menu-bt" href="cadastro.php" id="cadastro">Cadastro de Clientes</a></li>
                        <li><a class="menu-bt" href="arquivado.php" id="arquivado">Arquivamento de Cliente</a></li>
						<li><a class="menu-bt" href="remessa.php" id="remessa">Envio de Arquivo</a></li>
						<li><a class="menu-bt" href="historico.php" id="historico">Histórico</a></li>
						<li><a class="menu-bt" href="relatorio.php" id="relatorio">Relatório</a></li>
						<li><a class="menu-bt" href="administrador.php" id="administrador">Administradores</a></li>
						<li><a class="menu-bt" href="login.php">Sair</a></li>
				    </ul>
                </nav>
            </div>