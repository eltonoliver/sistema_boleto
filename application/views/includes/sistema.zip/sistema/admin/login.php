<?php include "include-header.php" ?>

		<div class="container">
			<div class="col-md-4"></div>
			
			<div class="col-md-4 lo-gin">
				<img src="../imagens/logo-civilcorp.png" alt="Civil Corp" width="" height="">
				
				<form action="" class="boxfor">
					<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email" required="required">
					<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Senha" required="required">
					<button type="submit" class="btn btn-default btnlog">Entrar</button>
				</form>
				
				
			</div>
			
			<div class="col-md-4"></div>
		</div>

<?php include "include-footer.php" ?>