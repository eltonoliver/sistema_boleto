					<div class="boxlogo"><img src="imagens/logo-civilcorp.png" alt="Civil Corp" width="" height=""></div>

					<div class="row">
						<nav>
							<ul id="menu">
								<li><a class="menu-bt" href="index.php" id="home">Home</a></li>
								<li><a class="menu-bt" href="meusdados.php" id="meusdados">Meus dados</a></li>
								<li><a class="menu-bt" href="historico.php" id="historico">Histórios</a></li>
								<li><a class="menu-bt" href="login.php">Sair</a></li>
							</ul>
						</nav>
					</div>